import {useContext} from "react";
import {UserContext} from "../Context/userContext"

export default () => useContext(UserContext);